# Example Package For CS310 Lab Assignment
## Information
### Name : [Srajan Chourasia](https://github.com/srajan-kiyotaka)
### Roll No.: 2003135
### Date: 09/11/2022
### Checkout My GiyHub Profile [💻](https://github.com/srajan-kiyotaka)
## Here is the [Link](https://test.pypi.org/project/example-package-Srajan-Chourasia/) to my Project for the Assignment.
### [example_package_Srajan_Chourasia](https://test.pypi.org/project/example-package-Srajan-Chourasia/)
## Here are some Instructions on How to Install:

```
pip install -i https://test.pypi.org/simple/ example-package-Srajan-Chourasia
```

### Alternate Command

```
python3 -m pip install --index-url https://test.pypi.org/simple/ --no-deps example-package-Srajan-Chourasia
```
